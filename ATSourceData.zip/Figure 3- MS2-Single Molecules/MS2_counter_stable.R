library(MSnbase)
library(ggplot2)
library("magrittr")
library("doSNOW")
library("foreach")
library("data.table")


MS2_num_from_mzML<- function(fname, filter.tics = 0){
    ### Read an mzML file and extract the number of MS2 peaks from each parent
    
    ## Read the file and run peak picking
    msexp <- readMSData(fname, msLevel =2, mode = "inMemory" )
    if (filter.tics != 0){
        msexp = msexp[tic(msexp) > filter.tics]
    }
    centroided = pickPeaks(msexp)
    n_spectra = length(centroided)
    print(paste("Reading MS Data from file: ", fname))
    ## Get the parent masses, round them and sort
    parent.masses = sort(unique(round(precursorMz(centroided), 2)))
    print(paste("Number of parents found: ", length(parent.masses)))
    flush.console()
    ## Get all the spectra associated with each parent mass
    #  record the possible isotopes of that mass
    matched.spectra.info <- data.frame("parent.mass" =c(), "spectra.ids" =c(), "possible.isotope.masses"=c(), "collision_energy" = c()) 
    
    for (parent in parent.masses){
        spectra_ids = which(round(precursorMz(centroided),2) %in% parent)
        c35_ids = spectra_ids[which(collisionEnergy(centroided[spectra_ids]) == 35)]
        c45_ids =spectra_ids[which(collisionEnergy(centroided[spectra_ids]) == 45)]
        
        possible_isotopes = parent.masses[which(abs(parent.masses - parent) == 1.0 & parent.masses != parent )]
        new.spectra.info = as.data.frame(cbind(parent.mass = c(parent), spectra_ids = list(c35_ids), 
                                               possible_isotopes = list(possible_isotopes), collision_energy = 35))
        matched.spectra.info = rbind(matched.spectra.info, new.spectra.info)
        new.spectra.info = as.data.frame(cbind(parent.mass = c(parent), spectra_ids = list(c45_ids), 
                                               possible_isotopes = list(possible_isotopes), collision_energy = 45))
        matched.spectra.info = rbind(matched.spectra.info, new.spectra.info)
        # 0 collision energy indicates to not seperate by collision energy
        new.spectra.info = as.data.frame(cbind(parent.mass = c(parent), spectra_ids = list(spectra_ids), 
                                               possible_isotopes = list(possible_isotopes), collision_energy = 0))
        matched.spectra.info = rbind(matched.spectra.info, new.spectra.info)
    }
    
    ## Get the number of spectra associated with each mass, and sort by the number of spectra
    matched.spectra.info$n_spectra = lengths(matched.spectra.info$spectra_ids)
    matched.spectra.info <- matched.spectra.info[order(matched.spectra.info$n_spectra, decreasing = TRUE),] #
    max.spectra <- max(matched.spectra.info$n_spectra)
    print(paste("Highest number of spectra associated with Parent: ", max.spectra ))
    flush.console()
    ### Duplicate Rows to run extra thresholds and noise floors
    thresholds = c(0.1, 0.15, 0.25, 0.5)
    noise_floors = c(2000,5000, 10000)
    #Remove rows with fewer than 3 associated spectra
    #matched.spectra.info <- matched.spectra.info[matched.spectra.info$n_spectra > 3,]
    # First duplicate the thresholds
    matched.spectra.info$threshold = 0.01
    # Make a dummy copy
    copy.df <- matched.spectra.info
    
    # Add all the thresholds
    for (t in thresholds){
        copy.df$threshold = t
        matched.spectra.info <- rbind(matched.spectra.info, copy.df)
    }
    # Do the same for the noise floors
    matched.spectra.info$noise_floor = 1000
    # Make a dummy copy
    copy.df <- matched.spectra.info
    # Add all the thresholds
    for (f in noise_floors){
        copy.df$noise_floor = f
        matched.spectra.info <- rbind(matched.spectra.info, copy.df)
    }
    
    
    n_rows = nrow(matched.spectra.info)
    matched.spectra.info$MS2.values <- -1
    for (i in 1:n_rows){ 
        matched.spectra.info$MS2.values[i] <- get_num_MS2_from_parents_consenus(centroided, matched.spectra.info$spectra_ids[i], threshold = matched.spectra.info$threshold[i], noise_floor = matched.spectra.info$noise_floor[i]) 
    }
    return(matched.spectra.info)
}

####################################################################################
get_num_MS2_from_parents_consenus <- function(centroid.data, indices, threshold = 0.25, mzd = 2.001, noise_floor = 5000){
    ### Get the number of consistent MS2 peaks from a collection of spectra 
    indices = unlist(indices, use.names = FALSE, recursive = TRUE)
    if (length(indices) > 3){
        # Get the maximum mass from the spectra (we shouldn't count anything above the parent mass -1)
        parent.mass <- min(precursorMz(centroid.data[indices])) - 1.0

        # Filter indices based on TICs. Use 1e5
        indices = indices[which(tic(centroid.data[indices]) > 1E5)]

        ## Initialize the number of peaks as NA. This will be returns if the spectra 
        #  is just noise
        num.peaks = -1

        ## If only 1-3 spectra are found its probably noise
        if (length(indices) > 3){
            theseSpectra = c()
            for (i in indices){

                theseSpectra = c(theseSpectra, removePeaks(centroid.data[[i]],noise_floor) )  
            }

            cSp = consensusSpectrum(theseSpectra, mzd = mzd, minProp = threshold)#, intensityFun = base::max)
            cSp = trimMz(cSp, c(2, parent.mass-1.01))
            #cSp = removePeaks(cSp, noise_floor )
            cSp = clean(cSp, all = TRUE)

            num.peaks = peaksCount(cSp)

        }
        else{
                num.peaks = -1.0
        }
    }
    else{
        num.peaks = -1.0
    }

    return(num.peaks)
}
####################################################################################
run_MS2_single_count <- function(fname, filter.tics= 0){
    base.name <- strsplit(fname, '.mzML')[[1]]
    csv.name <- paste0(base.name, "_Cole_R_analysis_consenus.csv")
    if (filter.tics > 0){
        csv.name <- paste0(base.name, "_Cole_R_analysis_tics_filtered.csv")
    }
    #print(csv.name)
    ### Get a save name for the csv output
    spectra.info <- MS2_num_from_mzML(fname)
    spectra.info <- as.data.table(spectra.info)
    fwrite(spectra.info, file = csv.name)
    #print(head(spectra.info))
    #write.csv(spectra.info, csv.name)    
}
####################################################################################
get.files.to.run <- function(dirname, filter.tics = 0 ){
    ## Collect all the mzML filenames in the directory
    mzML.files <- paste0(dirname,"/",list.files(path = dirname,pattern = "\\.mzML$", include.dirs = TRUE))
    ## Collect the output csv files also in the directory
    existing.csv.files <- paste0(dirname,"/",list.files(path = dirname,pattern = "\\_Cole_R_analysis_consenus.csv$", include.dirs = TRUE))
    if (filter.tics > 0){
        existing.csv.files <- paste0(dirname,"/",list.files(path = dirname,pattern = "\\_Cole_R_analysis_tics_filtered.csv$", include.dirs = TRUE))
    }
    
    ## For each mzML file generate the output name of the csv
    candidate.csv.files <- c()
    for (fname in mzML.files){
        base.name <- strsplit(fname, '.mzML')[[1]]
        csv.name <- paste0(base.name, "_Cole_R_analysis_consenus.csv")
        if (filter.tics > 0){
            csv.name <- paste0(base.name, "_Cole_R_analysis_tics_filtered.csv")
        }
        candidate.csv.files <- c(candidate.csv.files,csv.name)    
    }
    ## Get the difference between the outputs and the mzML files in the directory
    diff_files = setdiff(candidate.csv.files, existing.csv.files)
    mzML.files.to.run <- c()
    ## You want to run the difference so convert the file name back to the mzML 
    for (fname in diff_files){
        base.name <- strsplit(fname, "_Cole_R_analysis_consenus.csv")[[1]]
        if (filter.tics > 0){
            base.name <- strsplit(fname, "_Cole_R_analysis_tics_filtered.csv")[[1]]
        }
        mzML.name <- paste0(base.name, ".mzML" )
        mzML.files.to.run <- c(mzML.files.to.run,mzML.name)    
    }
    return(mzML.files.to.run)
}

####################################################################################

library("doSNOW")
library("foreach")
library("data.table")
run.all.mzml <- function(directory){
    cl <- makeCluster(35)
    registerDoSNOW(cl)
    #registerDoParallel(5)
    mzML.files <- get.files.to.run(directory, filter.tics = 1e5)

    
    nfiles <- length(mzML.files)
    print(nfiles)
    flush.console()
    
    temp <- foreach(i=1:nfiles,
            .export = c("run_MS2_single_count","MS2_num_from_mzML","get_num_MS2_from_parents_consenus", "mzML.files"),
            .packages = c("data.table", "MSnbase", "mzR")) %dopar% {
        
        run_MS2_single_count(mzML.files[i], filter.tics = 1e5)
    }
}